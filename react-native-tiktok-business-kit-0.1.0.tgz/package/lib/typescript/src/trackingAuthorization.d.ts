export declare enum TikTokTrackingAuthorizationStatus {
    NotDetermined = "notDetermined",
    Restricted = "restricted",
    Denied = "denied",
    Authorized = "authorized",
    Unavailable = "unavailable"
}
export declare const mapTrackingAuthorizationStatus: (raw: number) => TikTokTrackingAuthorizationStatus;
//# sourceMappingURL=trackingAuthorization.d.ts.map