import type { TikTokEventParams } from './types';
import { type TikTokTrackingAuthorizationStatus } from './trackingAuthorization';
declare const _default: {
    initialize: (config: import("./TiktokBusinessKit.nitro").TikTokInitializeConfig) => Promise<void>;
    identify: (user: import("./TiktokBusinessKit.nitro").TikTokIdentifyUser) => void;
    logout: () => void;
    flush: () => void;
    requestTrackingAuthorization(): Promise<TikTokTrackingAuthorizationStatus>;
    test: (a: string) => void;
    trackEvent(event: string, params?: TikTokEventParams, eventId?: string): void;
    trackEventRaw(event: string, paramsJson?: string, eventId?: string): void;
};
export default _default;
//# sourceMappingURL=TiktokBusinessKitModule.d.ts.map