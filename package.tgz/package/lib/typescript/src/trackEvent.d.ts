import type { TikTokEventParams } from './types';
export declare const serializeEventParams: (params?: TikTokEventParams) => string | undefined;
//# sourceMappingURL=trackEvent.d.ts.map