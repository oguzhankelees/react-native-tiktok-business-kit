export type TikTokBusinessConfig = {
	appId: string;
	appSecret: string;
	ttAppId: string;
	debug?: boolean;
};
  
export type TikTokContentItem = {
	content_id: string;
	content_type?: string;
	content_name?: string;
	currency?: string;
	price?: number;
	quantity?: number;
	brand?: string;
};

export type TikTokEventParams = Record<
	string,
	string | number | boolean | TikTokContentItem[] | undefined
>;
  
export type { TikTokIdentifyUser as TikTokUser } from './TiktokBusinessKit.nitro';

export const TikTokTrackingAuthorizationStatus = {
	NOT_DETERMINED: 0,
	RESTRICTED: 1,
	DENIED: 2,
	AUTHORIZED: 3,
	UNAVAILABLE: -1,
} as const;

export type TikTokTrackingAuthorizationStatusValue =
	(typeof TikTokTrackingAuthorizationStatus)[keyof typeof TikTokTrackingAuthorizationStatus];